import { motion } from 'motion/react';
import { ArrowUpRight, ArrowDown } from 'lucide-react';
import { CLINIC_IMAGES, CLINIC_INFO, buildWhatsAppUrl } from '../lib/clinicData';
import { ImageWithFallback } from './ImageWithFallback';

export function HeroSection() {
  const whatsappUrl = buildWhatsAppUrl();

  return (
    <section
      id="inicio"
      className="relative bg-surface-dark text-on-dark pt-10 pb-14 lg:pt-14 lg:pb-16 overflow-hidden"
    >
      <div className="max-w-[1280px] mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch min-h-[calc(100svh-10.5rem)]">
          {/* Coluna editorial de texto */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex flex-col justify-between py-2 lg:py-6"
          >
            <div className="space-y-7 max-w-xl">
              <p className="text-sm font-medium text-on-dark-muted">
                {CLINIC_INFO.specialty} · {CLINIC_INFO.city}
              </p>

              <h1 className="font-display font-semibold text-on-dark leading-[1.04] tracking-tight text-[clamp(2.5rem,4.5vw,4.25rem)]">
                Nutrição com ciência, leveza e resultado real.
              </h1>

              <p className="text-base sm:text-lg text-on-dark-muted leading-relaxed max-w-md">
                Atendimento clínico individualizado no Centro de Pindamonhangaba para equilibrar saúde, rotina e composição corporal.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-6">
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2.5 px-7 py-4 rounded-full bg-surface-light text-on-light font-display text-sm sm:text-base font-semibold tracking-tight hover:bg-surface-light-muted transition-transform duration-200 hover:-translate-y-0.5 active:translate-y-0 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-current"
                >
                  <span>Conversar no WhatsApp</span>
                  <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                </a>

                <a
                  href="#servicos"
                  className="inline-flex items-center gap-2 text-sm font-medium text-on-dark-muted hover:text-on-dark transition-colors duration-200 whitespace-nowrap shrink-0 py-2"
                >
                  <span>Explorar serviços</span>
                  <ArrowDown className="w-4 h-4 shrink-0" aria-hidden="true" />
                </a>
              </div>
            </div>

            <div className="pt-10 lg:pt-12 mt-10 border-t border-on-dark flex flex-wrap items-center gap-x-6 gap-y-2 text-xs sm:text-sm text-on-dark-muted">
              <span>Planos Alimentares</span>
              <span aria-hidden="true">·</span>
              <span>Bioimpedância</span>
              <span aria-hidden="true">·</span>
              <span>Acompanhamento Clínico</span>
            </div>
          </motion.div>

          {/* Coluna visual dominante */}
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1], delay: 0.08 }}
            className="lg:col-span-6 flex"
          >
            <div className="relative w-full min-h-[300px] sm:min-h-[400px] lg:min-h-[520px] rounded-3xl overflow-hidden border border-on-dark bg-surface-brand">
              <ImageWithFallback
                src={CLINIC_IMAGES.hero}
                alt="Consultório da Clínica Dyogo Oliveira com alimentos frescos, luz natural e ambiente acolhedor"
                loading="eager"
                fetchPriority="high"
                className="w-full h-full object-cover object-center lg:h-full"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
