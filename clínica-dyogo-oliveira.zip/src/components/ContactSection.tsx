import { useState, type FormEvent } from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight, Check, Copy, MapPin, Phone } from 'lucide-react';
import { CLINIC_INFO, buildWhatsAppUrl } from '../lib/clinicData';

const SERVICE_OPTIONS = [
  'Planos Alimentares Individualizados',
  'Avaliação por Bioimpedância',
  'Acompanhamento Contínuo',
] as const;

const PERIOD_OPTIONS = ['Manhã', 'Tarde', 'Indiferente'] as const;

interface FormErrors {
  name?: string;
  phone?: string;
}

export function ContactSection() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState<string>(SERVICE_OPTIONS[0]);
  const [period, setPeriod] = useState<string>(PERIOD_OPTIONS[0]);
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const directWhatsappUrl = buildWhatsAppUrl();

  function formatPhoneInput(value: string): string {
    const digits = value.replace(/\D/g, '').slice(0, 11);
    if (digits.length <= 2) return digits;
    if (digits.length <= 7) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nextErrors: FormErrors = {};
    const trimmedName = name.trim();
    const phoneDigits = phone.replace(/\D/g, '');

    if (trimmedName.length < 2) {
      nextErrors.name = 'Informe seu nome para o atendimento.';
    }
    if (phoneDigits.length < 10) {
      nextErrors.phone = 'Informe um WhatsApp com DDD válido.';
    }

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      setSubmittedUrl(null);
      return;
    }

    setErrors({});
    const customMessage = `Olá! Me chamo ${trimmedName} (WhatsApp: ${phone}). Gostaria de agendar "${service}" com preferência no período: ${period}.`;
    setSubmittedUrl(buildWhatsAppUrl(customMessage));
  }

  async function handleCopyAddress() {
    try {
      await navigator.clipboard.writeText(CLINIC_INFO.address);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2400);
    } catch {
      setCopied(false);
    }
  }

  return (
    <section
      id="contato"
      className="bg-surface-dark text-on-dark py-24 md:py-32"
    >
      <div className="max-w-[1280px] mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Informações de contato e localização */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 space-y-10"
          >
            <div className="space-y-4 max-w-lg">
              <p className="text-sm font-medium text-on-dark-muted">
                Agendamento e contato
              </p>
              <h2 className="font-display font-semibold text-on-dark leading-[1.06] text-[clamp(2rem,3.6vw,3.25rem)]">
                Dê o primeiro passo para sua saúde hoje.
              </h2>
              <p className="text-base sm:text-lg text-on-dark-muted leading-relaxed">
                Atendimento presencial no Centro de Pindamonhangaba com agendamento rápido direto pelo WhatsApp.
              </p>
            </div>

            <div className="space-y-6 pt-4 border-t border-on-dark">
              <div className="flex items-start gap-4">
                <MapPin className="w-5 h-5 mt-0.5 shrink-0 text-on-dark-muted" aria-hidden="true" />
                <div className="space-y-2">
                  <p className="text-sm font-medium text-on-dark-muted">
                    Endereço da clínica
                  </p>
                  <p className="text-base text-on-dark leading-relaxed max-w-md">
                    {CLINIC_INFO.address}
                  </p>
                  <div className="flex flex-wrap items-center gap-5 pt-1">
                    <button
                      type="button"
                      onClick={handleCopyAddress}
                      className="inline-flex items-center gap-1.5 text-sm font-medium text-on-dark-muted hover:text-on-dark transition-colors"
                    >
                      {copied ? (
                        <>
                          <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
                          <span>Endereço copiado</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 shrink-0" aria-hidden="true" />
                          <span>Copiar endereço</span>
                        </>
                      )}
                    </button>

                    <a
                      href={CLINIC_INFO.mapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-sm font-medium text-on-dark-muted hover:text-on-dark transition-colors"
                    >
                      <span>Ver no mapa</span>
                      <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                    </a>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="w-5 h-5 mt-0.5 shrink-0 text-on-dark-muted" aria-hidden="true" />
                <div className="space-y-1">
                  <p className="text-sm font-medium text-on-dark-muted">
                    Telefone e WhatsApp
                  </p>
                  <a
                    href={directWhatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-display text-lg font-semibold tabular-nums text-on-dark hover:opacity-80 transition-opacity"
                  >
                    {CLINIC_INFO.phoneDisplay}
                  </a>
                </div>
              </div>
            </div>

            <div>
              <a
                href={directWhatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 px-7 py-4 rounded-full bg-surface-light text-on-light font-display text-sm sm:text-base font-semibold tracking-tight hover:bg-surface-light-muted transition-transform duration-200 hover:-translate-y-0.5 active:translate-y-0 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-current"
              >
                <span>Conversar no WhatsApp</span>
                <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Agendamento Online integrado */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1], delay: 0.08 }}
            className="lg:col-span-6"
          >
            <div className="rounded-3xl bg-surface-light text-on-light p-7 sm:p-10 space-y-6">
              <div className="space-y-1.5">
                <h3 className="font-display text-2xl font-semibold text-on-light-strong">
                  Agendamento online
                </h3>
                <p className="text-sm text-on-light-muted">
                  Preencha seus dados para gerar a solicitação direta no WhatsApp.
                </p>
              </div>

              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                <div className="space-y-1.5">
                  <label
                    htmlFor="patient-name"
                    className="block text-sm font-medium text-on-light-strong"
                  >
                    Nome completo
                  </label>
                  <input
                    id="patient-name"
                    name="name"
                    type="text"
                    autoComplete="name"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                    }}
                    placeholder="Seu nome"
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'patient-name-error' : undefined}
                    className="w-full rounded-xl border border-on-light bg-surface-light px-4 py-3 text-base text-on-light-strong placeholder:text-on-light-muted/60 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-current"
                  />
                  {errors.name && (
                    <p id="patient-name-error" role="alert" className="text-xs font-medium text-on-light-strong">
                      {errors.name}
                    </p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="patient-phone"
                    className="block text-sm font-medium text-on-light-strong"
                  >
                    Seu WhatsApp
                  </label>
                  <input
                    id="patient-phone"
                    name="phone"
                    type="tel"
                    inputMode="tel"
                    autoComplete="tel"
                    value={phone}
                    onChange={(e) => {
                      setPhone(formatPhoneInput(e.target.value));
                      if (errors.phone) setErrors((prev) => ({ ...prev, phone: undefined }));
                    }}
                    placeholder="(12) 99999-9999"
                    aria-invalid={Boolean(errors.phone)}
                    aria-describedby={errors.phone ? 'patient-phone-error' : undefined}
                    className="w-full rounded-xl border border-on-light bg-surface-light px-4 py-3 text-base tabular-nums text-on-light-strong placeholder:text-on-light-muted/60 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-current"
                  />
                  {errors.phone && (
                    <p id="patient-phone-error" role="alert" className="text-xs font-medium text-on-light-strong">
                      {errors.phone}
                    </p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="service-select"
                    className="block text-sm font-medium text-on-light-strong"
                  >
                    Serviço desejado
                  </label>
                  <select
                    id="service-select"
                    name="service"
                    value={service}
                    onChange={(e) => setService(e.target.value)}
                    className="w-full rounded-xl border border-on-light bg-surface-light px-4 py-3 text-base text-on-light-strong focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-current"
                  >
                    {SERVICE_OPTIONS.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>

                <fieldset className="space-y-2">
                  <legend className="text-sm font-medium text-on-light-strong">
                    Preferência de período
                  </legend>
                  <div className="grid grid-cols-3 gap-2">
                    {PERIOD_OPTIONS.map((option) => {
                      const active = period === option;
                      return (
                        <button
                          key={option}
                          type="button"
                          onClick={() => setPeriod(option)}
                          aria-pressed={active}
                          className={`py-2.5 px-3 rounded-xl font-display text-sm font-medium transition-colors duration-150 whitespace-nowrap ${
                            active
                              ? 'bg-surface-brand text-on-dark'
                              : 'bg-surface-light-muted text-on-light hover:bg-surface-brand/10'
                          }`}
                        >
                          {option}
                        </button>
                      );
                    })}
                  </div>
                </fieldset>

                <button
                  type="submit"
                  className="w-full py-4 px-6 rounded-full bg-surface-brand text-on-dark font-display text-base font-semibold hover:opacity-95 transition-opacity whitespace-nowrap"
                >
                  Preparar agendamento
                </button>
              </form>

              {submittedUrl && (
                <div
                  role="status"
                  className="rounded-2xl border border-on-light bg-surface-light-muted p-5 space-y-3"
                >
                  <div className="flex items-center gap-2 text-sm font-semibold text-on-light-strong">
                    <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>Solicitação pronta para envio</span>
                  </div>
                  <p className="text-sm text-on-light-muted">
                    Clique abaixo para confirmar sua conversa com a clínica no WhatsApp.
                  </p>
                  <a
                    href={submittedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 w-full py-3.5 px-5 rounded-full bg-surface-brand text-on-dark font-display text-sm font-semibold hover:opacity-95 transition-opacity whitespace-nowrap"
                  >
                    <span>Conversar no WhatsApp</span>
                    <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                  </a>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
