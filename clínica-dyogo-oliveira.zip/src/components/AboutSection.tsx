import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { CLINIC_IMAGES, CLINIC_INFO, buildWhatsAppUrl } from '../lib/clinicData';
import { ImageWithFallback } from './ImageWithFallback';

export function AboutSection() {
  const whatsappUrl = buildWhatsAppUrl(
    'Olá, Dyogo! Gostaria de conhecer melhor o funcionamento da consulta nutricional.'
  );

  return (
    <section
      id="sobre"
      className="bg-surface-brand text-on-dark py-24 md:py-32"
    >
      <div className="max-w-[1280px] mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Retrato editorial com arco arquitetônico */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <div className="max-w-md mx-auto lg:mx-0 aspect-[3/4] rounded-t-[10rem] rounded-b-3xl overflow-hidden border border-on-dark bg-surface-dark">
              <ImageWithFallback
                src={CLINIC_IMAGES.portrait}
                alt="Nutricionista Dyogo Oliveira em seu consultório clínico"
                className="w-full h-full object-cover object-top"
              />
            </div>
          </motion.div>

          {/* Narrativa clínica concisa */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1], delay: 0.08 }}
            className="lg:col-span-7 space-y-8 max-w-2xl"
          >
            <div className="space-y-3">
              <p className="text-sm font-medium text-on-dark-muted">
                Sobre o atendimento
              </p>
              <h2 className="font-display font-semibold text-on-dark leading-[1.06] text-[clamp(2rem,3.6vw,3.25rem)]">
                Ciência nutricional aplicada à sua rotina.
              </h2>
            </div>

            <div className="space-y-5 text-base sm:text-lg text-on-dark-muted leading-relaxed">
              <p>
                Na {CLINIC_INFO.name}, cada consulta começa com escuta atenta sobre seus hábitos, preferências alimentares, histórico de saúde e metas pessoais.
              </p>
              <p>
                O foco é construir autonomia com comida de verdade, leitura precisa da composição corporal por bioimpedância e ajustes contínuos que respeitam o seu ritmo.
              </p>
            </div>

            <div className="pt-6 border-t border-on-dark grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="space-y-1">
                <p className="font-display text-base font-semibold text-on-dark">
                  Escuta clínica
                </p>
                <p className="text-sm text-on-dark-muted">
                  Plano moldado ao seu cotidiano.
                </p>
              </div>
              <div className="space-y-1">
                <p className="font-display text-base font-semibold text-on-dark">
                  Precisão técnica
                </p>
                <p className="text-sm text-on-dark-muted">
                  Dados reais de composição corporal.
                </p>
              </div>
              <div className="space-y-1">
                <p className="font-display text-base font-semibold text-on-dark">
                  Sem extremos
                </p>
                <p className="text-sm text-on-dark-muted">
                  Equilíbrio saudável a longo prazo.
                </p>
              </div>
            </div>

            <div className="pt-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 px-7 py-4 rounded-full bg-surface-light text-on-light font-display text-sm sm:text-base font-semibold tracking-tight hover:bg-surface-light-muted transition-transform duration-200 hover:-translate-y-0.5 active:translate-y-0 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-current"
              >
                <span>Conversar no WhatsApp</span>
                <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
