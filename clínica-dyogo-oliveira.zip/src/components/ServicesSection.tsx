import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { CLINIC_IMAGES, SERVICES, buildWhatsAppUrl } from '../lib/clinicData';
import { ImageWithFallback } from './ImageWithFallback';

export function ServicesSection() {
  const [mealPlan, bioimpedance, followUp] = SERVICES;

  return (
    <section
      id="servicos"
      className="relative bg-surface-light text-on-light rounded-t-[2rem] sm:rounded-t-[2.75rem] pt-24 pb-24 md:pt-32 md:pb-32"
    >
      <div className="max-w-[1280px] mx-auto px-5 sm:px-8">
        {/* Cabeçalho enxuto da seção */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-14 md:pb-18 border-b border-on-light"
        >
          <div className="max-w-xl space-y-3">
            <p className="text-sm font-medium text-on-light-muted">
              Serviços clínicos
            </p>
            <h2 className="font-display font-semibold text-on-light-strong leading-[1.08] text-[clamp(2rem,3.4vw,3.15rem)]">
              Cuidado nutricional pensado para durar.
            </h2>
          </div>
          <p className="text-base text-on-light-muted max-w-sm leading-relaxed">
            Cada etapa da consulta une precisão diagnóstica e praticidade para o seu dia a dia.
          </p>
        </motion.div>

        {/* Grid Bento assimétrico (anti-clichê 3 colunas iguais) */}
        <div className="pt-14 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
          {/* Card 01: Planos Alimentares (largo, com fotografia editorial de refeição) */}
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-8 rounded-3xl border border-on-light bg-surface-light-muted overflow-hidden grid grid-cols-1 md:grid-cols-12"
          >
            <div className="md:col-span-6 p-7 sm:p-9 flex flex-col justify-between gap-8">
              <div className="space-y-4">
                <span className="font-display text-sm font-semibold tabular-nums text-on-light-muted">
                  {mealPlan.number}
                </span>
                <h3 className="font-display text-2xl sm:text-3xl font-semibold text-on-light-strong leading-tight">
                  {mealPlan.title}
                </h3>
                <p className="text-base text-on-light-muted leading-relaxed">
                  {mealPlan.summary}
                </p>
              </div>

              <div className="pt-5 border-t border-on-light flex flex-wrap items-center gap-x-3 gap-y-1 text-xs sm:text-sm font-medium text-on-light">
                {mealPlan.details.map((detail, idx) => (
                  <span key={detail} className="inline-flex items-center gap-3">
                    <span>{detail}</span>
                    {idx < mealPlan.details.length - 1 && (
                      <span aria-hidden="true" className="opacity-40">
                        ·
                      </span>
                    )}
                  </span>
                ))}
              </div>
            </div>

            <div className="md:col-span-6 min-h-[260px] md:min-h-full">
              <ImageWithFallback
                src={CLINIC_IMAGES.mealPlan}
                alt="Prato equilibrado elaborado para plano alimentar individualizado com salmão, quinoa e vegetais frescos"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.article>

          {/* Card 03: Acompanhamento Contínuo (bloco contrastado em Azul Marinho) */}
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1], delay: 0.08 }}
            className="lg:col-span-4 rounded-3xl bg-surface-brand text-on-dark p-7 sm:p-9 flex flex-col justify-between gap-10"
          >
            <div className="space-y-4">
              <span className="font-display text-sm font-semibold tabular-nums text-on-dark-muted">
                {followUp.number}
              </span>
              <h3 className="font-display text-2xl sm:text-3xl font-semibold text-on-dark leading-tight">
                {followUp.title}
              </h3>
              <p className="text-base text-on-dark-muted leading-relaxed">
                {followUp.summary}
              </p>
            </div>

            <div className="space-y-6">
              <div className="pt-5 border-t border-on-dark flex flex-wrap items-center gap-x-3 gap-y-1 text-xs sm:text-sm font-medium text-on-dark-muted">
                {followUp.details.map((detail, idx) => (
                  <span key={detail} className="inline-flex items-center gap-3">
                    <span>{detail}</span>
                    {idx < followUp.details.length - 1 && (
                      <span aria-hidden="true" className="opacity-50">
                        ·
                      </span>
                    )}
                  </span>
                ))}
              </div>

              <a
                href={buildWhatsAppUrl(
                  'Olá! Gostaria de saber mais sobre o acompanhamento nutricional contínuo.'
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 font-display text-sm font-semibold text-on-dark hover:opacity-85 transition-opacity whitespace-nowrap"
              >
                <span>Conversar no WhatsApp</span>
                <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
              </a>
            </div>
          </motion.article>

          {/* Card 02: Avaliação por Bioimpedância (faixa horizontal invertida) */}
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-12 rounded-3xl border border-on-light bg-surface-light overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch"
          >
            <div className="lg:col-span-6 min-h-[280px] sm:min-h-[340px]">
              <ImageWithFallback
                src={CLINIC_IMAGES.bioimpedance}
                alt="Nutricionista apresentando resultados de avaliação por bioimpedância corporal durante consulta clínica"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="lg:col-span-6 p-7 sm:p-10 lg:p-12 flex flex-col justify-between gap-8">
              <div className="space-y-4 max-w-lg">
                <span className="font-display text-sm font-semibold tabular-nums text-on-light-muted">
                  {bioimpedance.number}
                </span>
                <h3 className="font-display text-2xl sm:text-3xl lg:text-4xl font-semibold text-on-light-strong leading-tight">
                  {bioimpedance.title}
                </h3>
                <p className="text-base sm:text-lg text-on-light-muted leading-relaxed">
                  {bioimpedance.summary}
                </p>
              </div>

              <div className="pt-6 border-t border-on-light flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs sm:text-sm font-medium text-on-light">
                  {bioimpedance.details.map((detail, idx) => (
                    <span key={detail} className="inline-flex items-center gap-3">
                      <span>{detail}</span>
                      {idx < bioimpedance.details.length - 1 && (
                        <span aria-hidden="true" className="opacity-40">
                          ·
                        </span>
                      )}
                    </span>
                  ))}
                </div>

                <a
                  href="#contato"
                  className="inline-flex items-center gap-1.5 font-display text-sm font-semibold text-on-light-strong hover:opacity-75 transition-opacity whitespace-nowrap shrink-0"
                >
                  <span>Agendar avaliação</span>
                  <ArrowUpRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                </a>
              </div>
            </div>
          </motion.article>
        </div>
      </div>
    </section>
  );
}
