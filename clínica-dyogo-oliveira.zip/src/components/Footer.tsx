import { CLINIC_INFO, buildWhatsAppUrl } from '../lib/clinicData';

const FOOTER_LINKS = [
  { label: 'Início', href: '#inicio' },
  { label: 'Serviços', href: '#servicos' },
  { label: 'Sobre', href: '#sobre' },
  { label: 'Orientações', href: '#orientacoes' },
  { label: 'Contato', href: '#contato' },
] as const;

export function Footer() {
  return (
    <footer className="bg-surface-dark-deep text-on-dark border-t border-on-dark">
      <div className="max-w-[1280px] mx-auto px-5 sm:px-8 py-12 md:py-14 flex flex-col gap-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <a
            href="#inicio"
            className="font-display text-lg font-semibold tracking-tight text-on-dark whitespace-nowrap"
          >
            {CLINIC_INFO.name}
          </a>

          <nav aria-label="Links do rodapé" className="flex flex-wrap items-center gap-x-7 gap-y-2">
            {FOOTER_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm text-on-dark-muted hover:text-on-dark transition-colors whitespace-nowrap"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="pt-6 border-t border-on-dark flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs sm:text-sm text-on-dark-muted">
          <p>{CLINIC_INFO.address}</p>
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
            <a
              href={buildWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="tabular-nums hover:text-on-dark transition-colors whitespace-nowrap"
            >
              WhatsApp {CLINIC_INFO.phoneDisplay}
            </a>
            <span aria-hidden="true">·</span>
            <span>© {new Date().getFullYear()} {CLINIC_INFO.name}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
