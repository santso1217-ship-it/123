import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { GUIDELINES } from '../lib/clinicData';

export function GuidelinesSection() {
  const [activeId, setActiveId] = useState<string>(GUIDELINES[0].id);
  const current = GUIDELINES.find((item) => item.id === activeId) ?? GUIDELINES[0];

  return (
    <section
      id="orientacoes"
      className="bg-surface-light text-on-light py-24 md:py-32"
    >
      <div className="max-w-[1280px] mx-auto px-5 sm:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start"
        >
          {/* Título e seletor editorial */}
          <div className="lg:col-span-5 space-y-6">
            <div className="space-y-3">
              <p className="text-sm font-medium text-on-light-muted">
                Dicas práticas
              </p>
              <h2 className="font-display font-semibold text-on-light-strong leading-[1.08] text-[clamp(2rem,3.2vw,2.85rem)]">
                Orientações para o dia a dia.
              </h2>
            </div>

            <div
              role="tablist"
              aria-label="Orientações nutricionais"
              className="flex flex-col border-t border-on-light"
            >
              {GUIDELINES.map((item) => {
                const isSelected = item.id === activeId;
                return (
                  <button
                    key={item.id}
                    role="tab"
                    type="button"
                    aria-selected={isSelected}
                    aria-controls={`panel-${item.id}`}
                    onClick={() => setActiveId(item.id)}
                    className={`group flex items-center justify-between gap-4 py-5 border-b border-on-light text-left transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-current ${
                      isSelected
                        ? 'text-on-light-strong'
                        : 'text-on-light-muted hover:text-on-light'
                    }`}
                  >
                    <span className="flex items-baseline gap-4">
                      <span className="font-display text-sm font-semibold tabular-nums opacity-70">
                        {item.number}
                      </span>
                      <span className="font-display text-lg sm:text-xl font-semibold">
                        {item.title}
                      </span>
                    </span>
                    <ArrowRight
                      className={`w-4 h-4 shrink-0 transition-transform duration-200 ${
                        isSelected
                          ? 'translate-x-0 opacity-100'
                          : '-translate-x-1 opacity-0 group-hover:opacity-60 group-hover:translate-x-0'
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Painel de leitura silencioso e espaçoso */}
          <div className="lg:col-span-7">
            <div
              id={`panel-${current.id}`}
              role="tabpanel"
              className="rounded-3xl border border-on-light bg-surface-light-muted p-8 sm:p-12 space-y-8"
            >
              <div className="space-y-2">
                <p className="text-sm font-medium text-on-light-muted">
                  {current.subtitle}
                </p>
                <h3 className="font-display text-2xl sm:text-3xl font-semibold text-on-light-strong leading-tight">
                  {current.title}
                </h3>
              </div>

              <p className="text-base sm:text-lg text-on-light-muted leading-relaxed">
                {current.body}
              </p>

              <div className="pt-6 border-t border-on-light space-y-1.5">
                <p className="text-xs font-medium text-on-light-muted">
                  Aplicação imediata
                </p>
                <p className="font-display text-base sm:text-lg font-medium text-on-light-strong">
                  {current.practicalStep}
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
