export const CLINIC_INFO = {
  name: 'Clínica Dyogo Oliveira',
  specialty: 'Nutricionista',
  city: 'Pindamonhangaba - SP',
  address: 'R. Frederico Machado, 132 - cj. 28 - Centro, Pindamonhangaba - SP, 12410-040',
  phoneDisplay: '(12) 99193-8585',
  phoneSanitized: '5512991938585',
  mapsUrl:
    'https://www.google.com/maps/search/?api=1&query=R.+Frederico+Machado,+132+-+Centro,+Pindamonhangaba+-+SP,+12410-040',
} as const;

export function buildWhatsAppUrl(customMessage?: string): string {
  const defaultMsg =
    'Olá! Gostaria de conversar sobre agendamento de consulta nutricional na Clínica Dyogo Oliveira.';
  const text = encodeURIComponent(customMessage ?? defaultMsg);
  return `https://wa.me/${CLINIC_INFO.phoneSanitized}?text=${text}`;
}

export const CLINIC_IMAGES = {
  hero: '/src/assets/images/hero_nutrition_clinic_1794929737700.jpg',
  mealPlan: '/src/assets/images/service_meal_plan_1794929738434.jpg',
  bioimpedance: '/src/assets/images/service_bioimpedance_1794929739001.jpg',
  portrait: '/src/assets/images/about_nutritionist_portrait_1794929739097.jpg',
} as const;

export interface ServiceItem {
  number: string;
  title: string;
  summary: string;
  details: string[];
}

export const SERVICES: ServiceItem[] = [
  {
    number: '01.',
    title: 'Planos alimentares individualizados',
    summary:
      'Estratégias nutricionais desenhadas para sua rotina, preferências e objetivos clínicos, sem cardápios genéricos.',
    details: ['Cardápio flexível', 'Lista de substituições', 'Foco na rotina real'],
  },
  {
    number: '02.',
    title: 'Avaliação por bioimpedância',
    summary:
      'Análise detalhada de composição corporal para acompanhar evolução clínica além do número na balança.',
    details: ['Massa muscular', 'Percentual de gordura', 'Hidratação corporal'],
  },
  {
    number: '03.',
    title: 'Acompanhamento contínuo',
    summary:
      'Consultas de retorno estruturadas e ajustes graduais para consolidar hábitos saudáveis ao longo do tempo.',
    details: ['Revisão de metas', 'Suporte entre consultas', 'Autonomia alimentar'],
  },
];

export interface NutritionGuideline {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  body: string;
  practicalStep: string;
}

export const GUIDELINES: NutritionGuideline[] = [
  {
    id: 'constancia',
    number: '01',
    title: 'Constância supera restrição severa',
    subtitle: 'Sustentabilidade clínica',
    body: 'Planos restritivos geram abandono rápido. Quando a alimentação respeita seus horários, cultura e paladar, a adesão acontece de forma natural e duradoura.',
    practicalStep: 'Comece ajustando uma refeição por semana em vez de mudar tudo no mesmo dia.',
  },
  {
    id: 'proteina',
    number: '02',
    title: 'Proteína distribuída ao longo do dia',
    subtitle: 'Saciedade e massa magra',
    body: 'Fracionar boas fontes proteicas entre café da manhã, almoço e janta estabiliza a saciedade, preserva musculatura e reduz picos de fome no fim da tarde.',
    practicalStep: 'Inclua uma fonte proteica simples já na primeira refeição da manhã.',
  },
  {
    id: 'hidratacao',
    number: '03',
    title: 'Hidratação como base metabólica',
    subtitle: 'Energia e digestão',
    body: 'Pequenos déficits hídricos afetam disposição, concentração e leitura da bioimpedância. Manter água acessível durante o trabalho melhora o bem-estar diário.',
    practicalStep: 'Associe um copo de água a cada pausa fixa da sua jornada de trabalho.',
  },
];
